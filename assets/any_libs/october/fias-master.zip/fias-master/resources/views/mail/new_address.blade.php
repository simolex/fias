<p> Сообщение с портала fias addresses </p>
<p>
    Адрес: {{ $fullAddress }} <br>
    Новый город: {{ $cityName }} <br>
    Новая улица: {{ $streetName }} <br>
    Новый дом: {{ $houseNumber  }} <br>
    Обратный email: {{ $return_email }}

    Для просмотра, кликните по <a href="{{ env('APP_URL') }}/get_all_applications_view">ссылке</a>
</p>