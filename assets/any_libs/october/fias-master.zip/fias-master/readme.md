## Развернуть
composer update

## Api с более новой (и оптимизированной версией находится по адресу)
https://fias.dev-io.ru/

Необходимо зарегистрироваться и пользоваться. Пока что в базе только Астраханские адреса. Если необхоидимо. 
Можем загнать и другие регионы. Пишите в issues.



Все города: https://fias.dev-io.ru/choose_cities?token=your_token
Все улицы: https://fias.dev-io.ru/choose_streets/cityaoguid?token=your_token
Все здания: https://fias.dev-io.ru/choose_buildings/streetaoguid?token=your_token
